return {
  'akinsho/toggleterm.nvim',
  version = "*",
  opts = {
    float_opts = { border = "curved", zindex = 100 }
  }
}
