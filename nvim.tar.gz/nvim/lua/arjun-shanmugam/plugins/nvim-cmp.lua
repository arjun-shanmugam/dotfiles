return {


  {
    "nvim-cmp",
    -- dependencies = {
    --   "hrsh7th/cmp-nvim-lsp",
    --   "hrsh7th/cmp-buffer",
    --   "hrsh7th/cmp-path",
    -- },
    --
    -- opts = function()
    --   local cmp = require("cmp")
    --   return {
    --     sources = cmp.config.sources({
    --       { name = "lazydev" },
    --       { name = "nvim_lsp" },
    --       { name = "path" },
    --     }, {
    --       { name = "buffer" },
    --     })
    --   }
    -- end,
  },

}
