return {
  "kkoomen/vim-doge"
}
