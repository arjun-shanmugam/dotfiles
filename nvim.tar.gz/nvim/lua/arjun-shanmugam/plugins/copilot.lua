require('copilot').setup(opts = {})
